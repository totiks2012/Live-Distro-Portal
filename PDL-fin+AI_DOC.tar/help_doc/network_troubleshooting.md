

### 📄 `help_doc/network_troubleshooting.md`

```markdown
# Диагностика сети в Live-среде

## Быстрая проверка подключения

Выполните в терминале:

```bash
ping -c 4 8.8.8.8
```

Если пакеты проходят — проблема в DNS.  
Если нет — проверьте физическое подключение или Wi-Fi.

> **Совет**: В некоторых дистрибутивах сетевой интерфейс по умолчанию выключен. Активируйте его через `nmcli` или графический апплет.

## Распространённые команды

| Команда                     | Назначение                          |
|----------------------------|-------------------------------------|
| `ip a`                     | Показать IP-адреса и интерфейсы     |
| `nmcli dev wifi list`      | Список доступных Wi-Fi сетей        |
| `journalctl -u NetworkManager` | Логи сетевого менеджера         |
| `dhclient -r && dhclient`  | Обновить DHCP-аренду                |

## Настройка вручную (если нет GUI)

1. Узнайте имя интерфейса:
   ```bash
   ls /sys/class/net
   ```
2. Поднимите интерфейс:
   ```bash
   sudo ip link set eth0 up
   ```
3. Получите IP:
   ```bash
   sudo dhclient eth0
   ```

### Если используется статический IP

Добавьте в `/etc/network/interfaces` (Debian/Ubuntu):

```conf
auto eth0
iface eth0 inet static
    address 192.168.1.100
    netmask 255.255.255.0
    gateway 192.168.1.1
    dns-nameservers 8.8.8.8
```

> ⚠️ **Важно**: Изменения в `/etc` в live-сессии **не сохраняются** после перезагрузки!

## Проверка DNS

```bash
nslookup archlinux.org
# или
dig @1.1.1.1 google.com
```

Если не работает — временно укажите DNS вручную:

```bash
echo "nameserver 8.8.8.8" | sudo tee /etc/resolv.conf
```
```

